# Architecture

## System boundary

TILKI OS is a Cloudflare Worker application with a React user interface, HTTP route handlers, and a D1 relational database. The first release uses deterministic agent playbooks so the complete decision workflow is testable without third-party credentials.

```mermaid
flowchart TD
    UI[React workspace] --> API[Route handlers]
    API --> Router[Agent router]
    API --> Store[(Cloudflare D1)]
    Router --> Rules[Specialist playbooks]
    Rules --> Store
    Store --> UI
```

## Main components

| Component | Responsibility |
| --- | --- |
| `app/tilki-dashboard.tsx` | Navigation, KPIs, task composer, recommendation review, and activity UI |
| `app/api/dashboard/route.ts` | Aggregated read model for the workspace |
| `app/api/agent/route.ts` | Input validation, task routing, and recommendation creation |
| `app/api/recommendations/[id]/route.ts` | Human approval or rejection |
| `lib/tilki-db.ts` | Database boundary, demo seed records, agent rules, and queries |
| `db/schema.ts` | Drizzle schema |
| `drizzle/` | Versioned D1 migration history |

## Data model

- `business_snapshots`: current headline metrics
- `recommendations`: agent output and review state
- `activities`: immutable workflow events
- `integrations`: provider readiness and connection status

## Decision control

Agents create recommendations; they do not directly execute external side effects. Approval writes the user decision and an activity record. A production adapter can later consume approved actions while preserving the same audit boundary.

## Next architecture step

Replace deterministic playbooks with a provider-neutral model gateway and typed tools. Keep each external adapter isolated behind explicit permissions, idempotency keys, audit events, and retry policies.
