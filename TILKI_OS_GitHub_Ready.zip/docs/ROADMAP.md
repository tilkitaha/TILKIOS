# Product roadmap

## Phase 1 — Working MVP

- [x] Responsive management dashboard
- [x] Specialist-agent navigation
- [x] Task routing
- [x] Recommendation approval workflow
- [x] Persistent D1 data
- [x] Activity history
- [x] Automated validation

## Phase 2 — Sem Kafe pilot

- [ ] Import anonymized hourly orders from CSV
- [ ] Add menu-item cost and gross-margin views
- [ ] Measure preparation time, stock-outs, and waste
- [ ] Compare AI recommendations against manager decisions
- [ ] Produce a weekly pilot report

## Phase 3 — Real integrations

- [ ] Google Reviews read/reply adapter
- [ ] Instagram content approval adapter
- [ ] WhatsApp Business follow-up adapter
- [ ] POS and delivery-order ingestion
- [ ] Calendar-based shift planning

## Phase 4 — Production SaaS

- [ ] Multi-tenant accounts and role-based access
- [ ] Provider-neutral LLM gateway
- [ ] Retrieval over business documents
- [ ] Permissioned tool execution
- [ ] Billing, observability, backups, and compliance controls

## Success measures

- Reduction in stock-outs and waste
- Faster manager decision time
- Change in preparation and service time
- Gross-margin improvement
- Recommendation approval rate and realized impact
