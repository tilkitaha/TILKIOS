# Deployment

## Option A — ChatGPT Sites

The repository already includes `.openai/hosting.json` with the logical `DB` D1 binding. Import the project into Sites, create a Site, validate the build, save a version, and publish it. Sites provisions the physical database and applies the tracked Drizzle migrations.

## Option B — Cloudflare Workers

1. Install dependencies and build:

   ```bash
   npm ci
   npm run build
   ```

2. Create a D1 database:

   ```bash
   npx wrangler d1 create tilki-os-db
   ```

3. Copy `wrangler.example.toml` to `wrangler.toml` and replace the placeholder database ID.

4. Apply the migration:

   ```bash
   npx wrangler d1 execute tilki-os-db --remote --file=drizzle/0000_nervous_ulik.sql
   ```

5. Deploy:

   ```bash
   npx wrangler deploy
   ```

## Production checklist

- Never commit provider tokens or customer data.
- Use separate development and production databases.
- Keep applied migration files immutable.
- Restrict public access until authentication is added.
- Label every integration as demo until a live adapter succeeds end to end.
