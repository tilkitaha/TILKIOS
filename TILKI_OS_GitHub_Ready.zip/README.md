# TILKI OS

**AI-powered operating system for small businesses.**

TILKI OS turns business signals into reviewable actions. A manager can monitor performance, route a goal to the right specialist agent, review the recommendation, and approve or reject it from one workspace.

> MVP status: the dashboard, APIs, database, task routing, approval workflow, and audit history are functional. External integrations and generative-model calls are intentionally represented as demo adapters until provider credentials are configured.

## What works

- Turkish business command center with responsive desktop/mobile UI
- KPI dashboard for revenue, orders, net profit, and customer rating
- AI Manager plus Marketing, Sales, Finance, Operations, Inventory, and Analytics agents
- Server-side task classification and specialist-agent routing
- Human-in-the-loop approval and rejection workflow
- Persistent recommendations, integration records, and activity history
- Cloudflare D1 schema with versioned migrations
- Automated build, component, schema, and quality checks

## Product flow

```mermaid
flowchart LR
    A[Business data] --> B[AI Manager]
    B --> C[Specialist agent]
    C --> D[Recommendation]
    D --> E{Human review}
    E -->|Approve| F[Record action]
    E -->|Reject| G[Record decision]
```

## Technology

- React 19 and TypeScript
- Vinext / Next.js-compatible App Router
- Cloudflare Workers
- Cloudflare D1
- Drizzle ORM and migrations
- Tailwind CSS and accessible UI primitives
- Node test runner and ESLint

## Run locally

Requirements: Node.js 22.13 or newer.

```bash
npm ci
npm run db:generate
npm run dev
```

The application expects a D1-compatible `DB` binding. See [deployment instructions](docs/DEPLOYMENT.md) for database setup.

## Validate

```bash
npm test
npm run lint
```

## API

| Method | Endpoint | Purpose |
| --- | --- | --- |
| `GET` | `/api/dashboard` | Load KPIs, recommendations, integrations, and activity |
| `POST` | `/api/agent` | Route a user goal and create a recommendation |
| `PATCH` | `/api/recommendations/:id` | Approve or reject a recommendation |

## Documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Deployment](docs/DEPLOYMENT.md)
- [Product roadmap](docs/ROADMAP.md)

## Safety and scope

The current release never claims to publish campaigns, send customer messages, order inventory, or update third-party systems. Every proposed action remains pending until a person approves or rejects it.

## License

MIT © 2026 Taha Can Tilkioğlu
